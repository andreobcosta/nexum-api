const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve frontend (PWA)
app.use(express.static(path.join(__dirname, '..', 'frontend', 'build')));

// API Routes
app.use('/api/patients', require('./routes/patients'));
app.use('/api/files', require('./routes/files'));
app.use('/api/reports', require('./routes/reports'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    app: 'RAN Clinic',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// PWA: serve index.html for all non-API routes
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, '..', 'frontend', 'build', 'index.html'));
  }
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Erro interno do servidor', details: err.message });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`
  ╔══════════════════════════════════════════╗
  ║        RAN Clinic — Backend API          ║
  ║  Rodando em http://0.0.0.0:${PORT}          ║
  ╚══════════════════════════════════════════╝
  `);
});
