const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');
const { getDb } = require('../db/connection');
const drive = require('../services/drive');
const claude = require('../services/claude');

// Load system prompt
const SYSTEM_PROMPT_PATH = path.join(__dirname, '..', 'prompts', 'system_prompt_ran.md');

function getSystemPrompt() {
  return fs.readFileSync(SYSTEM_PROMPT_PATH, 'utf-8');
}

// POST /api/reports/generate/:patient_id — Generate RAN report
router.post('/generate/:patient_id', async (req, res) => {
  const db = getDb();

  try {
    const patient = db.prepare('SELECT * FROM patients WHERE id = ?').get(req.params.patient_id);
    if (!patient) return res.status(404).json({ error: 'Paciente não encontrado' });
    if (!patient.drive_folder_id) return res.status(400).json({ error: 'Paciente sem pasta no Drive' });

    // Check completeness
    const files = db.prepare('SELECT category, COUNT(*) as count FROM files WHERE patient_id = ? GROUP BY category')
      .all(req.params.patient_id);

    const fileCounts = {};
    for (const f of files) fileCounts[f.category] = f.count;

    const missing = [];
    if (!fileCounts.anamnese) missing.push('Anamnese');
    if (!fileCounts.teste) missing.push('Testes');
    if (!fileCounts.sessao) missing.push('Sessões');

    if (missing.length > 0 && !req.body.force) {
      return res.status(400).json({
        error: 'Dados incompletos para gerar o relatório',
        missing,
        message: `Faltam: ${missing.join(', ')}. Envie force=true para gerar mesmo assim.`
      });
    }

    // Collect all text data from the database (transcriptions and notes)
    const allFiles = db.prepare('SELECT * FROM files WHERE patient_id = ? ORDER BY category, created_at')
      .all(req.params.patient_id);

    // Build the data package for Claude
    const dataPackage = {};
    for (const file of allFiles) {
      const folderName = drive.CATEGORY_TO_FOLDER[file.category] || file.category;
      if (!dataPackage[folderName]) dataPackage[folderName] = [];

      dataPackage[folderName].push({
        name: file.original_name,
        type: file.file_type,
        content: file.transcription
          ? Buffer.from(file.transcription).toString('base64')
          : '[Arquivo binário — conteúdo não textual]',
        size: file.transcription ? Buffer.byteLength(file.transcription) : 0
      });
    }

    // Also try to collect files directly from Drive (for PDFs that weren't transcribed)
    try {
      const driveData = await drive.collectPatientData(patient.drive_folder_id);
      for (const [folder, driveFiles] of Object.entries(driveData)) {
        if (!dataPackage[folder]) dataPackage[folder] = [];
        for (const df of driveFiles) {
          const alreadyExists = dataPackage[folder].some(f => f.name === df.name);
          if (!alreadyExists) {
            dataPackage[folder].push(df);
          }
        }
      }
    } catch (driveErr) {
      console.warn('Could not collect from Drive, using DB data only:', driveErr.message);
    }

    // Generate the report
    const systemPrompt = getSystemPrompt();
    const reportContent = await claude.generateRAN(systemPrompt, patient, dataPackage);

    // Save report to database
    const reportId = uuidv4();
    const existingReports = db.prepare('SELECT MAX(version) as max_v FROM reports WHERE patient_id = ?')
      .get(req.params.patient_id);
    const version = (existingReports?.max_v || 0) + 1;

    // Upload to Drive
    const reportFileName = `RAN_${patient.full_name.replace(/\s+/g, '_')}_v${version}_${new Date().toISOString().slice(0, 10)}.md`;
    let driveFileId = null;

    try {
      const subfolderId = await drive.getSubfolderId(patient.drive_folder_id, 'relatorio');
      const reportBuffer = Buffer.from(reportContent, 'utf-8');
      const driveFile = await drive.uploadBuffer(reportBuffer, reportFileName, 'text/markdown', subfolderId);
      driveFileId = driveFile.id;
    } catch (uploadErr) {
      console.warn('Could not upload report to Drive:', uploadErr.message);
    }

    db.prepare(`
      INSERT INTO reports (id, patient_id, version, drive_file_id, content_md, status)
      VALUES (?, ?, ?, ?, ?, 'draft')
    `).run(reportId, req.params.patient_id, version, driveFileId, reportContent);

    db.prepare("UPDATE patients SET status = 'relatorio_gerado', updated_at = datetime('now') WHERE id = ?")
      .run(req.params.patient_id);

    db.prepare('INSERT INTO activity_log (patient_id, action, details) VALUES (?, ?, ?)').run(
      req.params.patient_id, 'report_generated',
      JSON.stringify({ version, report_id: reportId, drive_file_id: driveFileId })
    );

    res.status(201).json({
      id: reportId,
      version,
      patient: patient.full_name,
      drive_file_id: driveFileId,
      drive_file_name: reportFileName,
      content_preview: reportContent.substring(0, 500) + '...',
      message: `Relatório v${version} gerado com sucesso`
    });

  } catch (err) {
    console.error('Report generation error:', err);
    res.status(500).json({ error: 'Erro ao gerar relatório', details: err.message });
  }
});

// GET /api/reports/:id — Get a specific report
router.get('/:id', (req, res) => {
  const db = getDb();
  const report = db.prepare('SELECT r.*, p.full_name FROM reports r JOIN patients p ON r.patient_id = p.id WHERE r.id = ?')
    .get(req.params.id);

  if (!report) return res.status(404).json({ error: 'Relatório não encontrado' });
  res.json(report);
});

// GET /api/reports/patient/:patient_id — List all reports for a patient
router.get('/patient/:patient_id', (req, res) => {
  const db = getDb();
  const reports = db.prepare('SELECT * FROM reports WHERE patient_id = ? ORDER BY version DESC')
    .all(req.params.patient_id);
  res.json(reports);
});

module.exports = router;
